package live.cricket.score;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.List;

import javax.xml.bind.JAXBException;

import live.cricket.feed.Rss;
import live.cricket.feed.Rss.Channel.Item;
import live.cricket.utils.ScoreUtils;

/**
 * @author lekshmana.murugan This class to read cricinfo feed and display feed
 *         information
 */
public class CricScoreFeed {

	public static Rss getLiveScoreObject() throws MalformedURLException,
			JAXBException {

		return (Rss) ScoreUtils.getUnMarshalObject(Rss.class, "live.score.url");

	}

	public static String formatScoreCard(Rss rss) {
		URL url = ClassLoader.getSystemResource("images/Cricket6.jpg");
		StringBuilder formatScoreCard = new StringBuilder();
		formatScoreCard.append("<html><body style='background-image: url("
				+ url.toString() + ");'>");
		formatScoreCard.append("<h3>")
				.append(rss.getChannel().getDescription()).append("- ")
				.append(rss.getChannel().getCopyright()).append("</h3>");
		formatScoreCard.append("Last updated <i>")
				.append(rss.getChannel().getPubDate()).append("</i><br />");
		List<Item> matchDetails = rss.getChannel().getItem();
		int i = 1;
		for (Item match : matchDetails) {
			formatScoreCard.append("<h4>Match ").append(i++).append("</h4>");
			formatScoreCard.append(match.getDescription()).append("<br />");
			formatScoreCard.append("Full Match Details - <i><a href='")
					.append(match.getLink()).append("'/>")
					.append("click here..").append("</a></i><br />");
			formatScoreCard.append(ScoreUtils.getShareWithScript(match
					.getLink()));
			formatScoreCard.append("<hr />");
		}
		formatScoreCard
				.append("Email Me - <a href='mailto:mlekshmanap@gmail.com?Subject=Cric%20Score%20App'>mlekshmanap@gmail.com</a><br />'");
		formatScoreCard.append("</body></html>");
		return formatScoreCard.toString();
	}
}
