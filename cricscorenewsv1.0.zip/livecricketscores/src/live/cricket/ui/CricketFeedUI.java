package live.cricket.ui;

import java.awt.Color;
import java.awt.Desktop;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.net.MalformedURLException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.TimeZone;

import javax.imageio.ImageIO;
import javax.swing.JEditorPane;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTabbedPane;
import javax.swing.event.HyperlinkEvent;
import javax.swing.event.HyperlinkListener;
import javax.swing.text.DefaultCaret;
import javax.xml.bind.JAXBException;

import live.cricket.feed.Rss;
import live.cricket.news.CricNewsFeed;
import live.cricket.score.CricScoreFeed;
import live.cricket.utils.ScoreUtils;

public class CricketFeedUI {

	private JFrame frmLiveCricketScores;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					CricketFeedUI window = new CricketFeedUI();
					window.frmLiveCricketScores.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 * 
	 * @throws JAXBException
	 * @throws MalformedURLException
	 */
	public CricketFeedUI() throws MalformedURLException, JAXBException {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 * 
	 * @throws JAXBException
	 * @throws MalformedURLException
	 */
	private void initialize() throws MalformedURLException, JAXBException {
		frmLiveCricketScores = new JFrame();
		frmLiveCricketScores.setResizable(false);

		try {
			frmLiveCricketScores.setIconImage(ImageIO.read(ClassLoader
					.getSystemResource("images/Cricketball2.png")));
		} catch (IOException e2) {
			// TODO Auto-generated catch block
			e2.printStackTrace();
		}
		frmLiveCricketScores.setTitle("Live Cricket Scores ");
		frmLiveCricketScores.setBounds(100, 100, 498, 604);
		frmLiveCricketScores.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frmLiveCricketScores.getContentPane().setLayout(null);

		JLabel lblThis = new JLabel(
				"Live Cricket Scores updated every 5 minutes, powered by lekshmanan, scores by espncricinfo");
		lblThis.setFont(new Font("Tahoma", Font.ITALIC, 10));
		lblThis.setBounds(48, 530, 456, 14);
		frmLiveCricketScores.getContentPane().add(lblThis);

		Rss rss = CricScoreFeed.getLiveScoreObject();

		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(0, 0, 457, 471);

		final JEditorPane dtrpnFdff = new JEditorPane();
		// Scroll automatically to make top
		final DefaultCaret caret = (DefaultCaret) dtrpnFdff.getCaret();
		caret.setUpdatePolicy(DefaultCaret.NEVER_UPDATE);

		scrollPane.setViewportView(dtrpnFdff);
		dtrpnFdff.setBackground(Color.WHITE);
		dtrpnFdff.setContentType("text/html");
		dtrpnFdff.setText(CricScoreFeed.formatScoreCard(rss));
		dtrpnFdff.setToolTipText("live cricket scores");
		dtrpnFdff.setEditable(false);

		JTabbedPane tabbedPane = new JTabbedPane(JTabbedPane.TOP);
		tabbedPane.setBounds(10, 11, 462, 499);
		frmLiveCricketScores.getContentPane().add(tabbedPane);

		JPanel liveScoreTab = new JPanel();
		tabbedPane.addTab("Live Score", null, liveScoreTab, "Score");
		liveScoreTab.setLayout(null);
		liveScoreTab.add(scrollPane);

		JPanel cricNewsTab = new JPanel();
		tabbedPane.addTab("Cric News", null, cricNewsTab, null);
		cricNewsTab.setLayout(null);

		JScrollPane scrollPane_1 = new JScrollPane();
		scrollPane_1.setBounds(0, 0, 457, 471);
		cricNewsTab.add(scrollPane_1);

		JEditorPane dtrpnSs = new JEditorPane();
		dtrpnSs.setFont(new Font("Bodoni MT", Font.PLAIN, 11));
		dtrpnSs.setContentType("text/html");

		final DefaultCaret caretNews = (DefaultCaret) dtrpnSs.getCaret();
		caretNews.setUpdatePolicy(DefaultCaret.NEVER_UPDATE);

		live.cricket.news.Rss rssNews = CricNewsFeed.getCricNewsObject();
		dtrpnSs.setText(CricNewsFeed.formatNews(rssNews));
		dtrpnSs.setEditable(false);
		dtrpnSs.setBackground(Color.WHITE);

		scrollPane_1.setViewportView(dtrpnSs);

		final JLabel lblNewLabel = new JLabel("New label");
		lblNewLabel.setBounds(81, 510, 376, 22);
		frmLiveCricketScores.getContentPane().add(lblNewLabel);
		// Wed, 06 Jan 2016 12:47:01
		ActionListener timeUpdate = new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				Date localTime = new Date();
				DateFormat converter = new SimpleDateFormat(
						"E, dd MMM yyyy HH:mm:ss z");
				// getting GMT timezone, you can get any timezone e.g. UTC
				converter.setTimeZone(TimeZone.getTimeZone("GMT"));
				lblNewLabel.setText("Current GMT Time - "
						+ converter.format(localTime).toString());
			}
		};

		new javax.swing.Timer(1000, timeUpdate).start();

		addHyperLinkListenerForComponents(dtrpnFdff);

		addHyperLinkListenerForComponents(dtrpnSs);

		ActionListener task = new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				try {
					Rss rss = CricScoreFeed.getLiveScoreObject();
					dtrpnFdff.setText(CricScoreFeed.formatScoreCard(rss));
				} catch (MalformedURLException | JAXBException e1) {
					e1.printStackTrace();
				}
			}
		};

		String refreshInterval = ScoreUtils
				.getResourceValue("live.score.refresh.seconds");
		new javax.swing.Timer(Integer.parseInt(refreshInterval), task).start();

	}

	private void addHyperLinkListenerForComponents(final JEditorPane dtrpnFdff) {
		dtrpnFdff.addHyperlinkListener(new HyperlinkListener() {
			@Override
			public void hyperlinkUpdate(HyperlinkEvent hle) {
				if (HyperlinkEvent.EventType.ACTIVATED.equals(hle
						.getEventType())) {
					System.out.println(hle.getURL());
					Desktop desktop = Desktop.getDesktop();
					try {
						desktop.browse(hle.getURL().toURI());
					} catch (Exception ex) {
						ex.printStackTrace();
					}
				}
			}
		});
	}
}
