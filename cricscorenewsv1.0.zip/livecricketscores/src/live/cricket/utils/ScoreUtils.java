package live.cricket.utils;

import java.lang.reflect.Field;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ResourceBundle;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;

public class ScoreUtils {

	public static ResourceBundle getResource() {
		ResourceBundle bundle = ResourceBundle.getBundle("i18n.livescore");
		return bundle;
	}

	public static <E> Object getUnMarshalObject(Class<E> rssClass,
			String propertyName) throws MalformedURLException, JAXBException {
		String url = ScoreUtils.getResourceValue(propertyName);
		URL liveScoreUrl = new URL(url);
		JAXBContext jaxbContext = JAXBContext.newInstance(rssClass.getPackage()
				.getName());
		Unmarshaller unmarshaller = jaxbContext.createUnmarshaller();
		Object rssLiveScoreObject = unmarshaller.unmarshal(liveScoreUrl);
		return rssLiveScoreObject;
	}

	public static String getResourceValue(String key) {
		return getResource().getString(key);
	}
	
	public static String getShareWithScript(String url) {
		StringBuilder script = new StringBuilder();
		script.append("Share with - ")
				.append("<a href='https://www.facebook.com/sharer/sharer.php?u=")
				.append(url).append("'>Facebook</a> | ");
		script.append("<a href='https://twitter.com/intent/tweet?status=")
				.append("%40lekshmanan1710++").append(url)
				.append("'>Twitter</a> | ");
		script.append("<a href='https://plus.google.com/share?url=")
				.append(url).append("'>Google+</a> ");
		return script.toString();
	}

	public static String objToString(Object object) {
		System.out.println("Overided method");
		StringBuilder result = new StringBuilder();
		String newLine = System.getProperty("line.separator");

		result.append(object.getClass().getName());
		result.append(" Object {");
		result.append(newLine);

		// determine fields declared in this class only (no fields of
		// superclass)
		Field[] fields = object.getClass().getDeclaredFields();

		// print field names paired with their values
		for (Field field : fields) {
			result.append("  ");
			field.setAccessible(true);
			try {
				result.append(field.getName());
				result.append(": ");
				// requires access to private field:
				result.append(field.get(object));
			} catch (IllegalAccessException ex) {
				System.out.println(ex);
			}
			result.append(newLine + newLine);
		}
		result.append("}");

		return result.toString();
	}
}
