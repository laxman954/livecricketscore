package live.cricket.news;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.List;

import javax.xml.bind.JAXBException;

import live.cricket.news.Rss.Channel.Item;
import live.cricket.utils.ScoreUtils;

public class CricNewsFeed {

	public static Rss getCricNewsObject() throws MalformedURLException,
			JAXBException {
		return (Rss) ScoreUtils.getUnMarshalObject(Rss.class, "live.news.url");
	}

	public static String formatNews(Rss rss) {
		URL url = ClassLoader.getSystemResource("images/Cricket6.jpg");
		StringBuilder formatNews = new StringBuilder();
		formatNews.append("<html><body style='background-image: url("
				+ url.toString() + ");'>");
		formatNews.append("<a href='")
				.append(rss.getChannel().getImage().getLink())
				.append("'><img src='")
				.append(rss.getChannel().getImage().getUrl())
				.append("' /></a>");
		formatNews.append("<p>").append(rss.getChannel().getTitle())
				.append("</p>");
		formatNews.append("<p>").append(rss.getChannel().getCopyright())
				.append("</p><hr />");
		List<Item> newsDetail = rss.getChannel().getItem();
		for (Item news : newsDetail) {
			formatNews.append("<h3>").append(news.getTitle()).append("</h3>");
			formatNews.append("<p>").append(news.getDescription())
					.append("</p>");
			formatNews.append("Full news Details - <i><a href='")
					.append(news.getLink()).append("'/>")
					.append("click here..").append("</a></i><br />");
			formatNews.append("<i>Pubilished Date - ")
					.append(news.getPubDate()).append("</i><br />");
			formatNews.append(ScoreUtils.getShareWithScript(news.getLink()));
			formatNews.append("<hr />");
		}
		formatNews
				.append("Email Me - <a href='mailto:mlekshmanap@gmail.com?Subject=Cric%20Score%20App'>mlekshmanap@gmail.com</a><br />'");
		formatNews.append("</body></html>");
		return formatNews.toString();
	}
}
